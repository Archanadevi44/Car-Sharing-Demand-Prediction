Steps to Run

### Prerequisites
Install Python 3.11 or higher.

### Install Required Libraries

pip install pandas numpy matplotlib seaborn scikit-learn


Run the Notebook
Open carsharing1.ipynb in Jupyter Notebook or VS Code and click “Run All”.

Outputs

Model performance metrics

Feature importance graphs

Predicted vs actual demand plots